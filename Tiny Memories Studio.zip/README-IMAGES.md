Image optimization removed

The project no longer generates WebP/AVIF images. The site will use the original PNG/JPG assets in `images/`.

If you later want to reintroduce optimization, recreate the optimizer script and CI workflow or run a local tool to produce WebP/AVIF images.
